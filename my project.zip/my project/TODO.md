# Task: Separate all pages from index.html

## Steps:
1. [x] Previous task complete (image linked)
2. [x] Update TODO.md for new task
3. [x] Create separate HTML files for each section: home.html, about-us.html, integrations.html, pricing.html, features.html
4. [x] Update index.html to landing page with nav links to new files
5. [x] Ensure nav/header/footer consistency across files
6. [x] Mark complete and verify

